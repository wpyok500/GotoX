#encoding: utf-8

import os, sys

def info():
    print(sys.path)
    print(os.getcwd())
    print(sys.getdefaultencoding())
    print(sys.prefix)
    print(sys.exec_prefix)

def setPath():
    pydir = os.path.dirname(sys.executable)
    spdir = os.path.join(pydir, 'site-packages')
    del sys.path[1:]
    sys.path.append(os.path.join(pydir, 'DLLs'))
    if os.path.exists(spdir):
        import glob
        sys.path.extend(glob.glob(os.path.join(spdir, '*.egg')))
        sys.path.append(spdir)
    sys.path.append(os.getcwd())
    #将 .egg 缓存位置放在 Python 目录
    os.environ['PYTHON_EGG_CACHE'] = os.path.join(pydir, 'Eggs-Cache')

def main():
    #info()
    setPath()
    #info()

main()
